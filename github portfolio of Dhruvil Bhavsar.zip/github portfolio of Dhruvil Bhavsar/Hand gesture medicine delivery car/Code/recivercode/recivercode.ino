/*
 * Project: Hand Gesture Control Robot (Receiver)
 * Hardware: ESP32 + L298N Motor Driver
 */

#include <esp_now.h>
#include <WiFi.h>

// Motor A Connections (Right)
int enA = 13;
int in1 = 12;
int in2 = 14;

// Motor B Connections (Left)
int enB = 25;
int in3 = 26;
int in4 = 27;

// Structure to receive data
typedef struct struct_message {
  float x;
  float y;
} struct_message;

struct_message incomingReadings;

// Callback function that will be executed when data is received
void OnDataRecv(const uint8_t * mac, const uint8_t *incomingData, int len) {
  memcpy(&incomingReadings, incomingData, sizeof(incomingReadings));
  controlCar(incomingReadings.x, incomingReadings.y);
}

void controlCar(float x, float y) {
  // Thresholds to determine movement (adjust based on sensitivity)
  // Forward/Backward based on Y-axis
  // Left/Right based on X-axis

  if (y < -5.0) { // Forward
    moveForward();
  } 
  else if (y > 5.0) { // Backward
    moveBackward();
  } 
  else if (x > 5.0) { // Left
    turnLeft();
  } 
  else if (x < -5.0) { // Right
    turnRight();
  } 
  else {
    stopCar();
  }
}

void moveForward() {
  digitalWrite(in1, HIGH); digitalWrite(in2, LOW);
  digitalWrite(in3, HIGH); digitalWrite(in4, LOW);
  analogWrite(enA, 200); analogWrite(enB, 200);
}

void moveBackward() {
  digitalWrite(in1, LOW); digitalWrite(in2, HIGH);
  digitalWrite(in3, LOW); digitalWrite(in4, HIGH);
  analogWrite(enA, 200); analogWrite(enB, 200);
}

void turnLeft() {
  digitalWrite(in1, HIGH); digitalWrite(in2, LOW);
  digitalWrite(in3, LOW); digitalWrite(in4, HIGH); // Counter-rotate
  analogWrite(enA, 150); analogWrite(enB, 150);
}

void turnRight() {
  digitalWrite(in1, LOW); digitalWrite(in2, HIGH); // Counter-rotate
  digitalWrite(in3, HIGH); digitalWrite(in4, LOW);
  analogWrite(enA, 150); analogWrite(enB, 150);
}

void stopCar() {
  digitalWrite(in1, LOW); digitalWrite(in2, LOW);
  digitalWrite(in3, LOW); digitalWrite(in4, LOW);
}

void setup() {
  Serial.begin(115200);
  
  // Set Motor Pins as Output
  pinMode(enA, OUTPUT); pinMode(in1, OUTPUT); pinMode(in2, OUTPUT);
  pinMode(enB, OUTPUT); pinMode(in3, OUTPUT); pinMode(in4, OUTPUT);

  WiFi.mode(WIFI_STA);
  if (esp_now_init() != ESP_OK) return;

  // Register callback
  esp_now_register_recv_cb(OnDataRecv);
}

void loop() {
  // Main loop does nothing, everything is handled in OnDataRecv
}