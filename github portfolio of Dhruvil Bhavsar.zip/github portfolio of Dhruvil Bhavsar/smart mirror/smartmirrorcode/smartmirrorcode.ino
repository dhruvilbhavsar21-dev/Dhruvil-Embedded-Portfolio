/*
 * Project: Smart Mirror Information Display
 * Hardware: ESP32, SSD1306 OLED, AHT20, BMP280, DS3231
 * Description: Displays environmental data and time on a mirror interface.
 */

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_AHTX0.h>
#include <Adafruit_BMP280.h>
#include <RTClib.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define SCREEN_ADDRESS 0x3C

// Initialize Objects
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
Adafruit_AHTX0 aht;
Adafruit_BMP280 bmp;
RTC_DS3231 rtc;

void setup() {
  Serial.begin(115200);

  // 1. Initialize OLED
  if (!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    Serial.println("SSD1306 allocation failed");
    for(;;);
  }
  display.clearDisplay();

  // 2. Initialize AHT20
  if (!aht.begin()) {
    Serial.println("AHT20 not found");
    while (1);
  }

  // 3. Initialize BMP280
  if (!bmp.begin()) {
    Serial.println("BMP280 not found");
    while (1);
  }

  // 4. Initialize RTC
  if (!rtc.begin()) {
    Serial.println("Couldn't find RTC");
    while (1);
  }

  if (rtc.lostPower()) {
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__))); // Sync with compilation time
  }
}

void loop() {
  // --- Data Collection ---
  sensors_event_t humidity, temp;
  aht.getEvent(&humidity, &temp); // Get AHT20 Data

  float bmpTemp = bmp.readTemperature();
  float pressure_hPa = bmp.readPressure() / 100.0F; // Pa to hPa

  DateTime now = rtc.now(); // Get Time

  // --- Display on OLED ---
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);

  // Display Humidity
  display.setCursor(0, 0);
  display.print("Hum: "); display.print(humidity.relative_humidity); display.println("%");

  // Display Temperature
  display.setCursor(0, 10);
  display.print("Temp: "); display.print(temp.temperature); display.println(" C");

  // Display Pressure
  display.setCursor(0, 20);
  display.print("Pres: "); display.print(pressure_hPa); display.println(" hPa");

  // Display Time (Bottom of screen)
  display.setCursor(0, 50);
  display.print(now.hour()); display.print(":");
  if (now.minute() < 10) display.print("0");
  display.print(now.minute()); display.print(":");
  if (now.second() < 10) display.print("0");
  display.println(now.second());

  display.display();
  delay(2000); // Refresh every 2 seconds
}