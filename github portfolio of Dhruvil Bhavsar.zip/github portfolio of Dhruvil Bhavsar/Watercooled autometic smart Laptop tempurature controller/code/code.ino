#include <OneWire.h>
#include <DallasTemperature.h>

// --- Configuration ---
const int SENSOR_PIN = 2;      // DS18B20 Data Pin
const int RELAY_PIN = 7;       // Relay Signal Pin
float USER_SET_TEMP = 30.0;    // Target Temperature (Celsius)
float HYSTERESIS = 2.0;        // Gap to prevent rapid switching

// --- Setup Objects ---
OneWire oneWire(SENSOR_PIN);
DallasTemperature sensors(&oneWire);

void setup() {
  Serial.begin(9600);
  sensors.begin();
  
  pinMode(RELAY_PIN, OUTPUT);
  
  // Start with cooling OFF
  // Note: Most relays are "Active LOW". 
  // If HIGH turns your relay ON, change this to LOW.
  digitalWrite(RELAY_PIN, HIGH); 
  
  Serial.println("System Initialized...");
}

void loop() {
  // 1. Get Temperature
  sensors.requestTemperatures(); 
  float currentTemp = sensors.getTempCByIndex(0);
  
  // Check if sensor is working
  if(currentTemp == -127.00) {
    Serial.println("Error: Sensor disconnected!");
    digitalWrite(RELAY_PIN, HIGH); // Force OFF for safety
    return;
  }

  Serial.print("Current Temp: ");
  Serial.print(currentTemp);
  Serial.print(" C | Target: < ");
  Serial.println(USER_SET_TEMP);

  // 2. Control Logic with Hysteresis
  // Case A: Temp is TOO HOT -> Turn Cooling ON
  if (currentTemp > (USER_SET_TEMP + HYSTERESIS)) {
    digitalWrite(RELAY_PIN, LOW); // Active LOW (Relay Closes)
    Serial.println("--> Cooling ACTIVATED");
  }
  
  // Case B: Temp is COLD ENOUGH -> Turn Cooling OFF
  else if (currentTemp < USER_SET_TEMP) {
    digitalWrite(RELAY_PIN, HIGH); // Active LOW (Relay Opens)
    Serial.println("--> Cooling OFF");
  }
  
  delay(2000); // Wait 2 seconds before next reading
}